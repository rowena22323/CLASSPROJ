// package com.classproject.testServer.dao;
// import java.util.List;

// import com.classproject.testServer.model.CentralLogin;

// public interface CentralLoginDAO {
//     public void insertUser(CentralLogin centrallogin) throws Exception;
// }